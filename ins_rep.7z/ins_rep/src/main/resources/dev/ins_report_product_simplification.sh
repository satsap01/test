#!/usr/bin/env bash

ODATE=${1}

CURRENT_PATH="$( dirname "$(readlink -f -- "$0")" )"
PROJECT_NAME=${CURRENT_PATH##*/}
PROJECT_PROPERTIES_DIR=$(readlink -f ${CURRENT_PATH}/../../../AppConfigs/Transformation/${PROJECT_NAME})
. ${PROJECT_PROPERTIES_DIR}/config.properties


sed -i "s@pathToReport=.*@pathToReport=${HDFS_PATH_TO_REPORT}@gi" ${LOCAL_APPCONFIGD_DIR}/${LOCAL_INPUT_FILE_NAME}
chmod -R 777 ${LOCAL_APPCONFIGD_DIR}/${LOCAL_INPUT_FILE_NAME}


echo "SCRIPT STARTS -------- `date`"
echo

if [ -z "$ODATE" ]
then
 ODATE=`date +%Y-%m-%d`
 echo "%ODATE was empty. Running with today's date $ODATE"
else
 echo "Running with date $ODATE"
fi
echo

spark2-submit \
--verbose \
--master ${SPARK_MASTER} \
--deploy-mode cluster \
--name ${PROJECT_NAME} \
--driver-java-options "-Dlog4j.debug=true -Dlog4j.configuration=file:log4j.properties -Ddi.spark2.log.driver.gw.folder=_${HDFS_LOG4J_EXECUTION_ID} -Ddi.spark2.run.hdfs.base.path=${HDFS_LOG4J_APPLOGS_DIR} -Ddi.spark2.run.execution.id=${HDFS_LOG4J_EXECUTION_ID} -Ddi.spark2.log.driver.filename.prefix=${HDFS_LOG4J_LOG_FILE_NAME_PREFIX} -Ddi.spark2.run.odate=${ODATE}" \
--conf "spark.executor.extraJavaOptions=-Dlog4j.debug=true -Dlog4j.configuration=file:log4j.properties -Ddi.spark2.log.driver.gw.folder=_${HDFS_LOG4J_EXECUTION_ID} -Ddi.spark2.run.hdfs.base.path=${HDFS_LOG4J_APPLOGS_DIR} -Ddi.spark2.run.execution.id=${HDFS_LOG4J_EXECUTION_ID} -Ddi.spark2.log.driver.filename.prefix=${HDFS_LOG4J_LOG_FILE_NAME_PREFIX} -Ddi.spark2.run.odate=${ODATE}" \
--num-executors ${SPARK_NUM_EXECUTORS} \
--executor-memory ${SPARK_EXECUTOR_MEMORY} \
--executor-cores ${SPARK_EXECUTOR_CORES} \
--driver-memory ${SPARK_DRIVER_MEMORY} \
--queue ${SPARK_QUEUE} \
--class ${PROJECT_DRIVER_CLASS} \
--conf spark.sql.parquet.compression.codec=snappy \
--files ${LOCAL_INPUT_FILE},${LOCAL_APPCONFIGD_DIR}/log4j.properties \
${LOCAL_JAR_FILE} \
ReportProductSimplificationDriver \
${ODATE} \
${LOCAL_INPUT_FILE_NAME}


echo "Copying logs from HDFS to local.. (${HDFS_LOG4J_APPLOGS_DIR}/logs/*${HDFS_LOG4J_EXECUTION_ID}* -> ${LOCAL_APPLOGS_DIR})" | tee /dev/tty
hdfs dfs -get ${HDFS_LOG4J_APPLOGS_DIR}/logs/*${HDFS_LOG4J_EXECUTION_ID}* ${LOCAL_APPLOGS_DIR}

echo "deleting logs from HDFS.. (${HDFS_LOG4J_APPLOGS_DIR}/logs/*${HDFS_LOG4J_EXECUTION_ID}*" | tee /dev/tty
hdfs dfs -rm -f -r -skipTrash ${HDFS_LOG4J_APPLOGS_DIR}/logs/*${HDFS_LOG4J_EXECUTION_ID}*

echo "deleting existing report from local ... ${LOCAL_APPLOGS_DIR}/${HDFS_REPORT_NAME}" | tee /dev/tty
rm -f -r ${LOCAL_APPLOGS_DIR}/${HDFS_REPORT_NAME} | tee /dev/tty

echo "Copying report from HDFS to local ...(${HDFS_PATH_TO_REPORT}/${HDFS_REPORT_NAME} -> ${LOCAL_APPLOGS_DIR}/${HDFS_REPORT_NAME})" | tee /dev/tty
hdfs dfs -get ${HDFS_PATH_TO_REPORT}/${HDFS_REPORT_NAME} ${LOCAL_APPLOGS_DIR}/${HDFS_REPORT_NAME}

echo "SCRIPT FINISH -------- `date`"
return
exit $?

echo "SCRIPT EXIT CODE = ${STATUS}"
