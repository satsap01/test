//------------->>>> fcalculation\common\SinkController.scala >>>>--------------
package com.santander.am.insurance.report.common

import org.apache.spark.sql.DataFrame

object SinkController
{
 def writeIntoPartition(df: DataFrame, database: String, table: String, fields: Seq[String], partition: String, partitionField: String = "date_processed"): Unit =
 {
 //Takes a dataframe and writes it into a specified table given the partition to write and the fields to use

 if(PropertyController.localTest)
 {
 df.createOrReplaceTempView(s"${table}_tmp")
 SparkController.spark.sql(s"INSERT OVERWRITE TABLE $table PARTITION ( $partitionField = '$partition' ) " +
 s"SELECT ${fields.mkString(",")} FROM ${table}_tmp")
 }
 else
 {
 df.createOrReplaceTempView(s"${table}_tmp")
 SparkController.spark.sql(s"INSERT OVERWRITE TABLE $database.$table PARTITION ( $partitionField = '$partition' ) " +
 s"SELECT ${fields.mkString(",")} FROM ${table}_tmp")
 }
 }

 def writeIntoPartition(df: DataFrame, database: String, table: String, partitions: Seq[String], fields: Seq[String], partitionFields: Seq[String]): Unit =
 {
 //This overload method is used where you wish to specify subpartitions to write into (will write in order of partitions given)

 if(PropertyController.localTest)
 {
 df.createOrReplaceTempView(s"${table}_tmp")
 SparkController.spark.sql(s"INSERT OVERWRITE TABLE $table " +
 s"PARTITION ( ${partitionFields.zip(partitions).map(x => x._1 + " = '" + x._2 + "'").mkString(",")} " +
 s"SELECT ${fields.mkString(",")} FROM ${table}_tmp")
 }
 else
 {
 df.createOrReplaceTempView(s"${table}_tmp")
 SparkController.spark.sql(s"INSERT OVERWRITE TABLE $database.$table " +
 s"PARTITION ( ${partitionFields.zip(partitions).map(x => x._1 + " = '" + x._2 + "'").mkString(",")} " +
 s"SELECT ${fields.mkString(",")} FROM ${table}_tmp")
 }
 }
}

