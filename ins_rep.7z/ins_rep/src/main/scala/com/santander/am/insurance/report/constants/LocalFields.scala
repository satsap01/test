//------------->>>> lculation\constants\Fields.scala >>>>--------------
//************************************************************************************************************/
//*** This class contains all the Fields name and Flags used in different different pipelines ***************/
//************************************************************************************************************/
package com.santander.am.insurance.report.constants

object LocalFields {
 var printFlag: Boolean = false
 var printCount: Int = 100
 var isClusterWindows:Boolean = false
}
