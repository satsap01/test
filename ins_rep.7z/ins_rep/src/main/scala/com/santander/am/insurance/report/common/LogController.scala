//------------->>>> fcalculation\common\LogController.scala >>>>--------------
//******************************************************************************************/
//*** This class copy Logs from Driver to HDFS path ****************************************/
//******************************************************************************************/
package com.santander.am.insurance.report.common

import org.apache.commons.io.FileUtils

import java.io._
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.hadoop.io.IOUtils

import scala.util.Try



object LogController {

 //***********************************************************
 // Following code is used to write logs from local to HDFS location
 //*******************Starts Here*******************************
 //*
// PropertyConfigurator.configure("sif_batch/src/main/resources/dev/log4j.properties")

 val conf = SparkController.spark.sparkContext.hadoopConfiguration

 def CopyLogsFromDriverToHDFS(): Unit = {
  InfoController.logMisc("Just Entered ...")

  val GWPath = System.getProperty("di.spark2.log.driver.gw.folder").trim
  val HDFSPath = System.getProperty("di.spark2.run.hdfs.base.path").trim
  val logsFolderName = "logs"

  val HDFSLogPath = if ((HDFSPath takeRight 1).equals("/")) {
    s"$HDFSPath$logsFolderName"
  } else {
    s"$HDFSPath/$logsFolderName"
  }

  InfoController.logMisc(s"Copying logs from driver to HDFS - from $GWPath to $HDFSLogPath")

  put(GWPath, HDFSLogPath)
  InfoController.logMisc(s"deleting driver logs - $GWPath")
  delete(new File(GWPath))
 }


 def put(GWPath: String, HDFSLogPath: String): Unit = {
  InfoController.logMisc("Just Entered ...")
  getFiles(GWPath).filter(_.length() > 0).map(file => {
   val hdfsConf = FileSystem.get(conf)
   val driverAbsolutePath = file.getAbsolutePath
   val driverFileName = file.getName
   val hdfsDestFilePath = new Path(HDFSLogPath + File.separator + driverFileName)
   try {
     val inputStream: InputStream = new FileInputStream(driverAbsolutePath);
     val fsDataOutputStream: FSDataOutputStream = hdfsConf.create(hdfsDestFilePath);
     IOUtils.copyBytes(inputStream, fsDataOutputStream, conf, true)
   } catch {
     case fnfe: FileNotFoundException => fnfe.printStackTrace();
     case ioe: IOException => ioe.printStackTrace();
   }
  })
 }

 def delete(file: File) {
  InfoController.logMisc("Just Entered ...")
  if (file.isDirectory)
    Option(file.listFiles).map(_.toList).getOrElse(Nil).foreach(FileUtils.deleteQuietly(_))
  Try(FileUtils.deleteDirectory(file))
 }


 def getFiles(GWPath: String): List[File] = {
  InfoController.logMisc("Just Entered ...")
  val d = new File(GWPath)
  if (d.exists && d.isDirectory) {
     d.listFiles.filter(_.isFile).toList
  } else {
     List[File]()
  }
 }

}
