//------------->>>> lculation\constants\Fields.scala >>>>--------------
//************************************************************************************************************/
//*** This class contains all the Fields name and Flags used in different different pipelines ***************/
//************************************************************************************************************/
package com.santander.am.insurance.report.constants

object Fields {

 val errorCode_Fatel = "FATAL"
 val errorCode_Warn = "WARN"
 val errorCode_NoMail = "NOMAIL"

}


















// val banding_table_change_Y = true
// val factor_table_change_Y = true


//var totaleuc=""
//var totalsifeuc=""
//var duplicatesifeuc=""
//var blanknullsifeuc=""
//
//var totalrel=""
//var totalsifrel=""
//var duplicatesifrel=""
//var lessinputrel=""
//
//var totalsif=""
//var validsif=""
//var duplicatesif=""
//var otherthenretailcust=""
//var blanknullsif=""
//var sifchange=""
//
//var totalreceived=""
//var bandingtablechange=""
//var factorstablechange=""

//var sifscoreFields: Seq[String] = _
//var sifenrichedrelativityFields: Seq[String] = _
//var ecusifscoreFields: Seq[String] = _
//var factorsFields: Seq[String] = _
//var bandingFields: Seq[String] = _
//
//var indent1Fields: Seq[String] = _
//var indent2Fields: Seq[String] = _
//var indent3Fields: Seq[String] = _
//var indent4Fields: Seq[String] = _
