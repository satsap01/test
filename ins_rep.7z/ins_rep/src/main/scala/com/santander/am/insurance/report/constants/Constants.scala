//------------->>>> lculation\constants\Constants.scala >>>>--------------
package com.santander.am.insurance.report.constants

object Constants {

}

