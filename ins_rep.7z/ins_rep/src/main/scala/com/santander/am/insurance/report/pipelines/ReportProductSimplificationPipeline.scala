//------------->>>> alculation\pipeline\ReportSIFRelativityPipeline.scala >>>>--------------
//*******************************************************************************************/
//*** This pipeline class generate reports for SIF Relativity table *************************/
//*** i.e. get reports attributes, check error's, write report and send email *************/
//******************************************************************************************/
package com.santander.am.insurance.report.pipelines

import com.santander.am.insurance.report.common.{InfoController, MailController, PropertyController, SourceController}
import org.apache.spark.sql.functions._

object ReportProductSimplificationPipeline {

   def execute(): Unit = {

     InfoController.logMisc("Just Entered ... ")

     val pathToReport: String = PropertyController.getProperties("pathToReport")
     val reportFileName:String = PropertyController.getProperties("reportFileName")
     val productSimplification: String = PropertyController.getProperties("product_simplification_query")
     val still_on_sale: String = PropertyController.getProperties("still_on_sale")
     val MAIL_SUBJECT: String = PropertyController.getProperties("MAIL_SUBJECT")
     val MAIL_BODY: String = PropertyController.getProperties("MAIL_BODY")

     val stillOnSaleMap = Map(still_on_sale.split(";").map(a=>a.split(",")).map(b=>b(0) -> b(1)): _*)
     def getStillOnSaleValue = udf((k:String) => stillOnSaleMap get k)

     val productSimplificationDF = SourceController.sourceDFLatestPartition(productSimplification)
     InfoController.logDFMisc(productSimplificationDF,"Dataframe created 'productSimplificationDF'")

     val productSimplificationNewDF = productSimplificationDF
       .withColumn("still_on_sale",getStillOnSaleValue(concat(col("product"),lit("|"),col("sub_product"))))
       .select("bank","product","sub_product","description","still_on_sale","total","last_contract")
     InfoController.logDFMisc(productSimplificationNewDF,"Dataframe created 'productSimplificationNewDF'")

     productSimplificationNewDF.coalesce(1).write.mode("overwrite")
       .option("sep","þ")
       .option("header","false")
       .option("ignoreTrailingWhiteSpace",false)
       .option("ignoreLeadingWhiteSpace",false)
       .csv(pathToReport)
     InfoController.logMisc(s"Report written to HDFS location $pathToReport")

     SourceController.renameFile(pathToReport,pathToReport + "/" + reportFileName)
     InfoController.logMisc(s"Report renamed to $pathToReport/$reportFileName")

     InfoController.logMisc("Sending Mail...")
     MailController.sendMailWithAttachment(MAIL_SUBJECT,MAIL_BODY,pathToReport + "/" + reportFileName)
     InfoController.logMisc("Mail Sent :)")
   }
}

