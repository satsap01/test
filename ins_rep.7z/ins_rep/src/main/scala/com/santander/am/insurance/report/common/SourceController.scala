//------------->>>> fcalculation\common\SourceController.scala >>>>--------------
//******************************************************************************************/
//*** This class contains generic method which are used by pipeline classes ***************/
//*****************************************************************************************/
package com.santander.am.insurance.report.common

import java.io.{File, PrintWriter}

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.DataFrame

import scala.collection.mutable
import scala.io.Source

object SourceController
{
 val conf = SparkController.spark.sparkContext.hadoopConfiguration
 val fs = FileSystem.get(conf)

 //Class to be a common point of access to table data, to maintain sourcing consistency, using dynamic SQL queries
 // Get dataframe from table for latest partition
 def sourceDFLatestPartition(query: String): DataFrame = {
 // Replace @odate@ with 'orderdate'
 val OriginalQuery:String = query.replaceAll("@odate@", "'" + PropertyController.orderDate + "'")
 val ListOfTables:List[String] = OriginalQuery.split("@maxodate@").toList.drop(1).map(a=>a.substring(0,a.indexOf("@")))
 val getLatestQuery:Map[String,String] = ListOfTables.map(a=>("@maxodate@" + a + "@","select max(date_processed) from " + a)).toMap
 val runQuery:Map[String,DataFrame] = getLatestQuery.map(a=>(a._1,SparkController.spark.sql(a._2)))
 val getLatestDate:Map[String,String] = runQuery.map(a=>(a._1,a._2.collect().toList)).map(a=>(a._1,a._2.mkString.replaceAll("\\[","").replaceAll("\\]","")))
 val replaceToLatestDate:String = getLatestDate.foldLeft (OriginalQuery) {case (acc,(key,value))=>acc.replaceAll(key, "'" + value + "'")}
 println("replaceToLatestDate "+replaceToLatestDate)
 val dfwithLatestPartition = SparkController.spark.sql(replaceToLatestDate)
 //println("df data is ---"+dfwithLatestPartition.show())
 dfwithLatestPartition
 }

 // Replace "@maxodate@DBName.TableName@" with latest date
 def getDates(query: String): String = {

 val OriginalQuery:String = query.replaceAll("@odate@", "'" + PropertyController.orderDate + "'")
 val ListOfTables:List[String] = OriginalQuery.split("@maxodate@").toList.drop(1).map(a=>a.substring(0,a.indexOf("@")))
 val getLatestQuery:Map[String,String] = ListOfTables.map(a=>("@maxodate@" + a + "@","select max(date_processed) from " + a)).toMap
 val runQuery:Map[String,DataFrame] = getLatestQuery.map(a=>(a._1,SparkController.spark.sql(a._2)))
 val getLatestDate:Map[String,String] = runQuery.map(a=>(a._1,a._2.collect().toList)).map(a=>(a._1,a._2.mkString.replaceAll("\\[","").replaceAll("\\]","")))
 val replaceToLatestDate:String = getLatestDate.foldLeft (OriginalQuery) {case (acc,(key,value))=>acc.replaceAll(key, "'" + value + "'")}
 println("replaceToLatestDate "+replaceToLatestDate)

 replaceToLatestDate
 }
// This method take list of report name and join them and rename it
 def joinReport(pathtoReport:String,reportFileName:String,filenames:List[String]): Unit ={
 //read all the report from respective path provided in filename list, merge it and rename it.
  val temppath = "join-sif-report-temp-path"

  val joinReport = filenames.map(filename => SparkController.spark.read.textFile(pathtoReport + filename)).reduce(_.union(_))
  .coalesce(1).write.mode("overwrite").format("text").save(pathtoReport + temppath)

  renameFile(pathtoReport + temppath,pathtoReport + reportFileName)
  fs.delete(new Path(pathtoReport + temppath), true)
 }

 def renameFile(oldPath:String, newPath:String) = {
  val file = fs.globStatus(new Path(oldPath + "/part*"))(0).getPath().getName()

  //to delete sif-analytics-${PropertyController.orderDate}.txt file if it already exist, then rename the file and delete temp path
  if(fs.exists(new Path(newPath))) {fs.delete(new Path(newPath),true) }
  fs.rename(new Path(oldPath + File.separator + file), new Path(newPath))
 }
}

