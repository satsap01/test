//------------->>>> fcalculation\common\SourceController.scala >>>>--------------
//******************************************************************************************/
//*** This class contains generic method which are used by pipeline classes ***************/
//*****************************************************************************************/
package com.santander.am.insurance.report.common

import com.santander.am.insurance.report.constants.{Fields, Params}
import org.apache.hadoop.fs.{FileSystem, Path}

import java.io.PrintWriter
import scala.collection.mutable
import scala.io.Source

object ValidationController
{
 // This method creates requested file path and write's the report and validation errors in it.
 def printStatistics(pathtoReport:String, StatisticsMap: mutable.LinkedHashMap[String, String], errorList: mutable.ListBuffer[String],templatePath:String): Unit = {
  val conf = SparkController.spark.sparkContext.hadoopConfiguration
  val fs = FileSystem.get(conf)
  val w = new PrintWriter(fs.create(new Path(pathtoReport)))

  Source.fromFile(templatePath).getLines
    .map { x =>
     x.split(" ").map(y => {
      if (StatisticsMap.keys.toSeq.contains(y)) {
       StatisticsMap(y).toString
      }
      else if (y == Params.validation_errors) {
       errorList.mkString("\n") + s"\n"
      }
      else y
     }).mkString(" ")
    }
    .foreach(x => w.println(x))
  w.close()
 }
 //This method decides which mail handler to trigger, i.e if fatalError is there then fatalErrorHandler is triggered
 def errorHandler(fatalError:Boolean,warnError:Boolean,noError:Boolean,path:String,errorList:mutable.ListBuffer[String] = new mutable.ListBuffer[String](),warnBody:String,warnSubject:String,errorBody:String,errorSubject:String): Unit =
 {
 //Separate handler per possible outcome
 if (fatalError) fatalErrorHandler(path,errorList,errorBody,errorSubject)
 else if (warnError) warnErrorHandler(path,errorList,warnBody,warnSubject)
 else if (noError) okHandler(path)
 }

// This method send the email to requested email id's if the report is Okay
 def okHandler(path:String): Unit =
 {
 //Send the report in the event of an OK run
 val body: String = Params.okBody.replace("\"", "")
 val subject: String = Params.okSubject.replace("\"","")
 println("path :" + path)
 MailController.sendMailWithAttachment(subject,body,path)
 }

// This method send the email to requested email id's if the report is having any Warning's
 def warnErrorHandler(path:String,errorList:mutable.ListBuffer[String],warnBody:String,warnSubject:String): Unit =
 {
 //Send the report in the event of a run with warnings
 val body: String = warnBody.replace("\"","") + "\n" + errorList.mkString(" \n")
 val subject: String = warnSubject.replace("\"","")
 println("path :" + path)
 MailController.sendMailWithAttachment(subject,body,path)
 }
// This method send the email to requested email id's if the report is having any fatal error's
 def fatalErrorHandler(path:String,errorList:mutable.ListBuffer[String],errorBody:String,errorSubject:String): Unit =
 {
 //Send the report and hold the batch in the event of a serious data error
 val body: String = errorBody.replace("\"","") + "\n" + errorList.mkString(" \n")
 val subject: String = errorSubject.replace("\"","")
 MailController.sendMailWithAttachment(subject,body,path)
 }

 // This method sets error Flag's and calculate exit code
 def createError(ListOfErrorStatus:mutable.ListBuffer[(Int,String,String)]) = {
 //If an error exists, determine which error flag to set, add the flag to the error code and log the error
 //Currently implemented in the SourceController to output this error to the report itself
 var exitCode: Int = 0
 val errorList: mutable.ListBuffer[String] = new mutable.ListBuffer[String]()
 var noError: Boolean = false
 var warnError: Boolean = false
 var fatalError: Boolean = false

 ListOfErrorStatus.foreach {
 case (errorId, description, errorCode) => {
 errorList.append(description)
 if (errorCode.toUpperCase == Fields.errorCode_Fatel || errorCode.toUpperCase == Fields.errorCode_Warn) {
 exitCode += math.pow(2, errorId).toInt
 }
 if (fatalError || errorCode.toUpperCase == Fields.errorCode_Fatel) {
 fatalError = true
 warnError = false
 noError = false
 }else if (warnError || errorCode.toUpperCase == Fields.errorCode_Warn) {
 warnError = true
 noError = false
 }else if (errorCode.toUpperCase == Fields.errorCode_NoMail){
 noError = false
 }else {noError = true}
 }
 }
 (exitCode,errorList,fatalError,warnError,noError)
 }

}

