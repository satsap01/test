//------------->>>> fcalculation\common\customFunctions.scala >>>>--------------
package com.santander.am.insurance.report.common

//import java.io.{File, PrintWriter}
//import java.nio.file.attribute.BasicFileAttributes
//import java.nio.file.{Files, Paths}

//import scala.io.Source
import org.apache.spark.sql.DataFrame

import scala.io.Source

object customFunctions {
 def printDF(printFlag:Boolean,df:DataFrame,dfName:String,numRow:Int) = {
 if (printFlag) {
 println(">>>>>>>>>>>>>>>>>> : " + dfName)
 df.show(numRow, false)
 println(">>>>>>> Count is : " + df.count)
 }
 }

 def getOdate() = {
 val configFile = "1_Data/resources/parameter/config.yml"
 val customDataMap: Map[String, List[String]] = getDataMap(configFile)
 // val odate = customDataMap("ODATE")(0).mkString
 val Day = customDataMap("DAYNUMBER")(0).mkString.toInt
 val odate = customDataMap("PARTITIONDATES")(Day -1)
 odate
 }

 def getDataMap(datafilename:String) = {
 def getFileContentsWithoutCommentLines(filename: String): List[String] = {
 (for (line <- Source.fromFile(filename).getLines
 if !line.trim.matches("")
 if !line.trim.matches("#.*")) yield line
 ).toList
 }
 val datalines = getFileContentsWithoutCommentLines(datafilename).mkString.split(" - ").drop(1)
 val dataMap:Map[String, String] = Map(datalines.map(y => y.split("@")).map(z => {
 if (z.size == 1)
 z(0).toUpperCase.trim -> ""
 else
 z(0).toUpperCase.trim -> z(1).trim
 }): _*)
 dataMap.map(a => {if (a._2.contains(",")) (a._1 -> a._2.split(",").map(_.trim).toList) else (a._1 -> List(a._2))})
 }
}
