package com.santander.am.insurance.report.drivers

import com.santander.am.insurance.report.common.{PropertyController, SparkController}
import com.santander.am.insurance.report.constants.LocalFields.{printCount, printFlag}

object MainDriver_Cluster_Run {
 def main(args: Array[String]): Unit = {
  println("Hello World!")
  args.foreach(println)
  println("Hello World!")
  var args1:Array[String]=Array()
  SparkController.start()
  println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Start")
  args.foreach(println)
  println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> End")
  args(0) match{
   case "ReportProductSimplificationDriver"=>{
    args1 = args.tail
    ReportProductSimplificationDriver.main(args1)
   }
  }
 }
}