//------------->>>> fcalculation\common\InfoController.scala >>>>--------------
package com.santander.am.insurance.report.common

import java.io.FileInputStream
import java.util.Properties
import org.apache.log4j.{Level, Logger, PropertyConfigurator}
import org.apache.spark.sql.DataFrame



object LoggerObj {
 var logObj : Logger = Logger.getLogger("spark2Logger")

//Following lines allow log4j works in windows
// Please uncomment following line to see the logs in Windows :)
/*
 private val LOG_FILE = "sif_batch/src/main/resources/dev/log4j.properties"
 val properties = new Properties();
 properties.load(new FileInputStream(LOG_FILE))
 PropertyConfigurator.configure(properties)
*/
}

object InfoController {

 val appStart = "--------------- APP START ----------------------"
 val appFinish = "-------------- APP FINISH ----------------------"

 def logTables (identifier: String): Unit = {
 println(s"${identifier.padTo(20," ").mkString} ** Loaded ---------")
 println()
 LoggerObj.logObj.log(Level.INFO, s"${identifier.padTo(20," ").mkString} ** Loaded ---------")
 }

 def logPipelineStart (identifier: String): Unit = {
 println()
 println(s"${identifier.padTo(20," ").mkString} --------- PIPELINE STARTS ---------")
 LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} --------- PIPELINE STARTS ---------")
 println()
 }

 def logPipelineFinish (identifier: String): Unit = {
 println()
 println(s"${identifier.padTo(20," ").mkString} --------- PIPELINE FINISH ---------")
 LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} --------- PIPELINE FINISH ---------")
 println()
 }

 def logMethodStart (identifier: String): Unit = {
 println(s"${identifier.padTo(20," ").mkString} ** Running ---------")
 LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} ** Running ---------")
 }

 def logMethodFinish (identifier: String): Unit = {
 println(s"${identifier.padTo(20," ").mkString} ** Finished ---------")
 LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} ** Finished ---------")
 }

 def logWriteToHDFS (identifier: String,anotherIdentifier:String=" ** Written ---------"): Unit = {
 println(s"${identifier.padTo(20," ").mkString}${anotherIdentifier}")
 LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString}${anotherIdentifier}")
 println()
 }

 def logReadFromHDFS (identifier: String): Unit = {
 println(s"${identifier.padTo(20," ").mkString} ** Read ---------")
 LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} ** Read ---------")
 println()
 }

 def logDFStart (identifier: String): Unit = {
  println(s"${identifier.padTo(20," ").mkString} ** Running ---------")
  LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} ** DF Creation Started ---------")
 }

 def logDFFinish (identifier: String): Unit = {
  println(s"${identifier.padTo(20," ").mkString} ** Finished ---------")
  LoggerObj.logObj.log(Level.INFO,s"${identifier.padTo(20," ").mkString} ** DF Creation Finished ---------")
 }

 def logMisc (description:String=""): Unit = {
  val className = Thread.currentThread.getStackTrace()(2).getClassName.split('.').last
  val methodName = Thread.currentThread.getStackTrace()(2).getMethodName

//  println(s"Class  - ${className.padTo(50," ").mkString}, Method - ${methodName.padTo(50," ").mkString}, ** - ${description}")
  LoggerObj.logObj.log(Level.INFO,s"Class  - ${className.padTo(50," ").mkString}, Method - ${methodName.padTo(50," ").mkString}, ** - ${description}")
 }

 def logDFMisc (df:DataFrame,description:String=""): Unit = {
  val className = Thread.currentThread.getStackTrace()(2).getClassName.split('.').last
  val methodName = Thread.currentThread.getStackTrace()(2).getMethodName

//  println(s"Class  - ${className.padTo(50," ").mkString}, Method - ${methodName.padTo(50," ").mkString}, ** - ${description}")
  LoggerObj.logObj.log(Level.INFO,s"Class  - ${className.padTo(50," ").mkString}, Method - ${methodName.padTo(50," ").mkString}, ** - ${description.padTo(100," ").mkString}, : ${df.count}")
 }

}

