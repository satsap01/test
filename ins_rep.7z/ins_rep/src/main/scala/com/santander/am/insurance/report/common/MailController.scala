//------------->>>> fcalculation\common\MailController.scala >>>>--------------
//******************************************************************************************/
//*** This class reads report file from HDFS location adn send it to requested email id ****/
//*****************************************************************************************/
package com.santander.am.insurance.report.common

import com.santander.am.insurance.report.constants.Params

import java.util.Properties

import javax.activation.{DataHandler, FileDataSource}
import javax.mail._
import javax.mail.internet.{InternetAddress, MimeBodyPart, MimeMessage, MimeMultipart}
import javax.mail.util.ByteArrayDataSource
import org.apache.hadoop.fs.{FileSystem, Path}

object MailController {

 val MAIL_TO: String = PropertyController.getProperties("MAIL_TO")
 val MAIL_FROM: String = PropertyController.getProperties("MAIL_FROM")
 val MAIL_HOST: String = PropertyController.getProperties("MAIL_HOST")
 val MAIL_PORT: String = PropertyController.getProperties("MAIL_PORT")
 val MAIL_PS: String = PropertyController.getProperties("MAIL_PS")

 def sendMailWithAttachment(subject: String, body: String, pathToFile: String): Unit = {
  InfoController.logMisc("Preparing to send mail...")
  if(PropertyController.localTest) { return }

  var to = MAIL_TO

  val host = MAIL_HOST
  val props = new Properties

  props.put("mail.smtp.starttls.enable", "true")
  props.put("mail.smtp.host", host)
  props.put("mail.smtp.port", MAIL_PORT)
  props.put("mail.smtp.auth", "true")

  val session = Session.getInstance(props)

  try {
   //Builds the message to send from its parts using the javax mail API
   val message = new MimeMessage(session)

   message.setFrom(new InternetAddress(MAIL_FROM))
   message.addRecipients(Message.RecipientType.TO, to)

   message.setSubject(subject + " - " + PropertyController.orderDate)
   var messageBodyPart = new MimeBodyPart
   messageBodyPart.setText(body)

   val multipart = new MimeMultipart
   multipart.addBodyPart(messageBodyPart)
   messageBodyPart = new MimeBodyPart
   //To read file from HDFS filesystem
   val conf = SparkController.spark.sparkContext.hadoopConfiguration
   val fs= FileSystem.get(conf)
   val path = new Path(pathToFile)
   val stream = fs.open(path)

   messageBodyPart.setDataHandler(new DataHandler(new ByteArrayDataSource(stream,"text/txt")))
   messageBodyPart.setFileName(pathToFile.split("/").last)
   multipart.addBodyPart(messageBodyPart)
   message.setContent(multipart)

   val transport = session.getTransport("smtp")
   InfoController.logMisc("Connecting to send mail")
   transport.connect(host, MAIL_FROM, MAIL_PS)
   InfoController.logMisc("Connection successful, sending mail")
   transport.sendMessage(message, message.getAllRecipients)
   InfoController.logMisc("Mail sent :)")

  } catch {
   case e: MessagingException =>
    throw new RuntimeException(e)
  }
 }

 def sendMailWithAttachment_hold(subject:String, body:String,pathToFile:String,x:Boolean=true): Unit = {
  val to="Satvinder.agriminfotech@gmail.com"
  val host="smtp.gmail.com"
  val email_port="587"
  val email_username= "Satvinder.agriminfotech@gmail.com"
  val email_password="Agrima@01"
  val email_starttls_enable="true"

  val properties = new Properties()
   properties.put("mail.smtp.port", email_port)
   properties.put("mail.smtp.host", host)
   properties.put("mail.smtp.starttls.enable", email_starttls_enable)
   properties.put("mail.smtp.auth", "true")
   properties.put("mail.smtp.ssl.trust", host)
   properties.put("mail.smtp.ssl.enable", "true")

  //  properties.put("mail.debug", "true")

  val session = Session.getInstance(properties)
  val message = new MimeMessage(session)

  val toia = InternetAddress.parse(to).asInstanceOf[Array[Address]]

  message.setFrom(new InternetAddress(email_username))
  message.setRecipients(Message.RecipientType.TO,toia)

  message.setSubject(subject + " - " + PropertyController.orderDate)
  var messageBodyPart = new MimeBodyPart
  messageBodyPart.setText(body)

  val multipart = new MimeMultipart
  multipart.addBodyPart(messageBodyPart)
  messageBodyPart=new MimeBodyPart

  val filename = pathToFile
  val source = new FileDataSource(filename)

  messageBodyPart.setDataHandler(new DataHandler(source))
  messageBodyPart.setFileName(pathToFile.split("/").last)
  multipart.addBodyPart(messageBodyPart)
  message.setContent(multipart)

  val transport = session.getTransport("smtp")
  transport.connect(host, email_username, email_password)
  transport.sendMessage(message, message.getAllRecipients)

 }

 def sendMailWithAttachment_NoMail(subject: String, body: String, pathToFile: String): Unit = {
 println()
 println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
 println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Mail Sent>>>>>>>>>>>>>>>>>>>>>>>>>>>")
 println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
 println("S U B J E C T : " + subject)
 println()
 println("B O D Y : " + body)
 println()
 println("P A T H T O F I L E : " + pathToFile)
 println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
 println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
 println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
 println()
 println()
 }
 def sendMailWithAttachment_STOP(subject: String, body: String, pathToFile: String): Unit = {
 //This method sends an email using Santander's internal email SMTP relay with an attachment

 println("Into MailController class")
 //We won't attempt to send an email if running the application locally
 if(PropertyController.localTest) { return }

 var to = PropertyController.emailList.mkString(",")

 val host = Params.relayHost
 val props = new Properties
 
 props.put("mail.smtp.starttls.enable", "false")
 props.put("mail.smtp.host", host)
 props.put("mail.smtp.port", "25")
 props.setProperty("mail.mime.address.strict", "false")

 val session = Session.getInstance(props)

 try {
 //Builds the message to send from its parts using the javax mail API
 val message = new MimeMessage(session)

 message.setFrom(new InternetAddress(Params.fromEmail))
 message.addRecipients(Message.RecipientType.TO, to)

 message.setSubject(subject + " - " + PropertyController.orderDate)
 var messageBodyPart = new MimeBodyPart
 messageBodyPart.setText(body)

 val multipart = new MimeMultipart
 multipart.addBodyPart(messageBodyPart)
 messageBodyPart = new MimeBodyPart
 //To read file from HDFS filesystem
 val conf = SparkController.spark.sparkContext.hadoopConfiguration
 val fs= FileSystem.get(conf)
 val path = new Path(pathToFile)
 val stream = fs.open(path)

 messageBodyPart.setDataHandler(new DataHandler(new ByteArrayDataSource(stream,"text/txt")))
 messageBodyPart.setFileName(pathToFile.split("/").last)
 multipart.addBodyPart(messageBodyPart)
 message.setContent(multipart)

 Transport.send(message)

 } catch {
 case e: MessagingException =>
 throw new RuntimeException(e)
 }
 }
}
