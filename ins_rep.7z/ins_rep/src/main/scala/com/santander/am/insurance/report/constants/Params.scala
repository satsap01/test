//------------->>>> lculation\constants\Params.scala >>>>--------------
//************************************************************************************************************/
//*** This class contains all the Parameters values used in different different pipelines ***************/
//************************************************************************************************************/
package com.santander.am.insurance.report.constants

object Params {

 var okSubject = "(DEV) Daily SIF Analytics Statistics Report"
 var okBody = "The SIF Analytics Report Process has now run and has verified the SIF Report is OK. The statistics report is attached."
 var validation_errors="validation_errors"
 val relayHost="relay.sanuk.santander.corp"
 val fromEmail=""
 val to=""
}

