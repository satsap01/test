package com.santander.am.insurance.report.drivers

import com.santander.am.insurance.report.common.{InfoController, LogController, PropertyController}
import com.santander.am.insurance.report.pipelines.ReportProductSimplificationPipeline

object ReportProductSimplificationDriver
{

 def main(args: Array[String]): Unit =
 {
 //Driver class for the SIF Relativity table report process. This is the method that is to be called when submitting the Spark job
 //Properties are set prior to executing the pipeline and the exit code is taken from its execution method

 InfoController.logMisc("Starting - Product Simplification Report")
 PropertyController.setOrderDate(args(0))
 PropertyController.loadProperties(args(1))
// PropertyController.setemailList(args(2))

// SparkController.start()
 InfoController.logMisc("Spark Started")

 InfoController.logMisc("Calling Pipeline class : ReportProductSimplificationPipeline")
// sys.exit(ReportSIFRelativityPipeline.run())
 ReportProductSimplificationPipeline.execute()

 InfoController.logMisc("Calling LogController class : CopyLogsFromDriverToHDFS()")
 LogController.CopyLogsFromDriverToHDFS()
 InfoController.logMisc("Finished - Product Simplification Report")
 }
}

