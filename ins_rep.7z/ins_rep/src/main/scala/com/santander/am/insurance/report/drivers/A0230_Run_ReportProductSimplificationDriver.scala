package com.santander.am.insurance.report.drivers

import com.santander.am.insurance.report.common.{InfoController, PropertyController, SparkController, customFunctions}
import com.santander.am.insurance.report.constants.LocalFields.isClusterWindows
import org.apache.log4j.PropertyConfigurator
import sun.java2d.cmm.CMSManager.getModule

import java.util.Properties

object A0230_Run_ReportProductSimplificationDriver extends App {
 println( "Hello World!" )

 isClusterWindows = true

 val odate = customFunctions.getOdate()
 println(">>>>>>>>>>>>>>>>> odate is " + odate)

 //****************************
 //Log4j Setting
 //*****************************
 val moduleName = "ins_rep"
 System.setProperty("di.spark2.log.driver.gw.folder",moduleName + "/src/main/resources/dev/Sink/log4j")
 System.setProperty("di.spark2.run.hdfs.base.path",moduleName + "/src/main/resources/dev/Sink/Rep_Enrich/log4j")
 System.setProperty("di.spark2.log.driver.filename.prefix","ABC")
 System.setProperty("di.spark2.run.odate",odate)
 System.setProperty("di.spark2.run.execution.id","001")

 val log4jPath = moduleName + "/src/main/resources/dev/log4j.properties"
 PropertyConfigurator.configure(log4jPath)
//*******************************


 val args1 = Array(odate,"ins_rep/src/main/resources/dev/input.properties","ins_rep/src/main/resources/dev/config.properties")
 SparkController.startLocalTest()

 ReportProductSimplificationDriver.main(args1)
}
