//------------->>>> fcalculation\common\SparkController.scala >>>>--------------
//******************************************************************************************/
//*** This common class, and used to create, start and stop Spark session ***************/
//*****************************************************************************************/
package com.santander.am.insurance.report.common

import org.apache.spark.sql.SparkSession

object SparkController {
 //Global controller class to access spark configuration and context

 var spark : SparkSession = _
 var testStarted : Boolean = false

 def start(): Unit =
 {
 //Starting the process requires establishing the Spark and Hive contexts
 spark = SparkSession
 .builder()
 .appName("sif-batch")
 .config("hive.exec.dynamic.partition", "true")
 .config("hive.exec.dynamic.partition.mode", "nonstrict")
 .config("javax.jdo.option.ConnectionURL","jdbc:derby:memory:;databaseName=metastore_db;create=true")
 .enableHiveSupport()
 .getOrCreate()
 spark.sparkContext.setLogLevel("ERROR")

 println("Spark Session started")

 }

 //Starts the Hive context, keeps dynamic partitioning enabled and reduces log clutter
// hiveContext = new HiveContext(sparkContext)
// hiveContext.setConf("hive.exec.dynamic.partition", "true")
// hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
// hiveContext.sparkContext.setLogLevel("OFF")

 def startLocalTest(): Unit =
 {
 println("we start Local Test")
 spark = SparkSession
 .builder()
 .appName("ip-status-table-test")
 .master("local[*]")
 .config("spark.executor.memory", "2g")
 .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
 .config("spark.sql.warehouse.dir","1_Data/resources/spark-warehouse/main.db")
 .config("hive.exec.scratchdir", "C:\\tmp\\hive")
 .config("hive.exec.dynamic.partition", "true")
 .config("hive.exec.dynamic.partition.mode", "nonstrict")
 // .config("hive.metastore.warehouse.dir", "file:///C:/tmp/hive/warehouse")
 // .config("javax.jdo.option.ConnectionURL", "jdbc:derby:;databaseName=C:\\tmp\\metastore;create=true")
 .enableHiveSupport()
 .getOrCreate()

 spark.sparkContext.setLogLevel("OFF")

 testStarted = true
 println("SPARK SESSION LOCAL TEST STARTED ---")
 // val parallelism: Int = 1
 // .config("spark.sql.shuffle.partitions", s"$parallelism")
 // .config("spark.sql.warehouse.dir", s"${Paths.get(".").toAbsolutePath}/target/hive")
 }

 def createLocalTable(): Unit =
 {
 spark.sql("DROP DATABASE IF EXISTS insurance CASCADE")
 spark.sql("CREATE DATABASE insurance")
 spark.sql("USE insurance")

 spark.sql("""CREATE TABLE IF NOT EXISTS instant_price_status ( vendor STRING, santander_customer_type STRING, santander_customer_number DECIMAL(9,0), santander_identifier_alphabet STRING, santander_identifier_numeric BIGINT, mortgage_reference_number STRING, product_code STRING, subproduct_code STRING, description STRING, sent_status STRING, receive_status STRING, tp_refresh_flag STRING, tp_enriched_flag STRING, instant_price DECIMAL(15,2), error_code STRING, recycle_counter INT, sent_date STRING, received_date STRING, santander_timestamp STRING ) PARTITIONED BY (date_processed STRING ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' """.stripMargin)
 println("---instant_price_status created")
 }


 def stop(): Unit =
 {
 //Terminates the SparkSession
 spark.stop()
 }

 def stageName(name: String): Unit =
 {
 //This is used to display the name of the current functionality being used in the Spark UI
 spark.sparkContext.setLocalProperty("callSite.short", name)
 }

 def stageDescription(description: String): Unit =
 {
 //This is used to display information about the current process in the Spark UI
 spark.sparkContext.setLocalProperty("callSite.long", description)
 }
}
